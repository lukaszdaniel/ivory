#include <R.h> /* required for R specific stuff */





